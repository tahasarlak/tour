import { notFound } from "next/navigation";

import { prisma } from "@/lib/prisma";
import { getAdminSession } from "@/lib/auth";

import ProductPageContent, { type ProductPageProduct } from "@/components/product/ProductPageContent";

import {
  PRODUCT_TYPES,
  type ProductType,
} from "@/lib/product-types";

// ==========================================
// FORCE DYNAMIC
// ==========================================

export const dynamic = "force-dynamic";

// ==========================================
// TYPES
// ==========================================

type Props = {
  params: Promise<{
    type: string;
    slug: string;
  }>;
};

// ==========================================
// STATIC PARAMS
// ==========================================

export async function generateStaticParams() {
  const [
    tours,
    trainTickets,
    flightTickets,
    busTickets,
    accommodations,
    touristVisas,
  ] = await Promise.all([
    // =========================
    // TOURS
    // =========================

    prisma.tour.findMany({
      where: {
        isPublished: true,
      },
      select: {
        slug: true,
      },
    }),

    // =========================
    // TRAIN
    // =========================

    prisma.trainTicket.findMany({
      where: {
        isPublished: true,
      },
      select: {
        slug: true,
      },
    }),

    // =========================
    // FLIGHT
    // =========================

    prisma.flightTicket.findMany({
      where: {
        isPublished: true,
      },
      select: {
        slug: true,
      },
    }),

    // =========================
    // BUS
    // =========================

    prisma.busTicket.findMany({
      where: {
        isPublished: true,
      },
      select: {
        slug: true,
      },
    }),

    // =========================
    // ACCOMMODATION
    // =========================

    prisma.accommodation.findMany({
      where: {
        isPublished: true,
      },
      select: {
        slug: true,
      },
    }),

    // =========================
    // VISA
    // =========================

    prisma.touristVisa.findMany({
      where: {
        isPublished: true,
      },
      select: {
        slug: true,
      },
    }),
  ]);

  return [
    // =========================
    // TOURS
    // =========================

    ...tours.map((item) => ({
      type: "tour",
      slug: item.slug,
    })),

    // =========================
    // TRAIN
    // =========================

    ...trainTickets.map((item) => ({
      type: "train",
      slug: item.slug,
    })),

    // =========================
    // FLIGHT
    // =========================

    ...flightTickets.map((item) => ({
      type: "flight",
      slug: item.slug,
    })),

    // =========================
    // BUS
    // =========================

    ...busTickets.map((item) => ({
      type: "bus",
      slug: item.slug,
    })),

    // =========================
    // ACCOMMODATION
    // =========================

    ...accommodations.map((item) => ({
      type: "accommodation",
      slug: item.slug,
    })),

    // =========================
    // VISA
    // =========================

    ...touristVisas.map((item) => ({
      type: "visa",
      slug: item.slug,
    })),
  ];
}

// ==========================================
// PRODUCT PAGE
// ==========================================

export default async function ProductPage({
  params,
}: Props) {
  const { type, slug } = await params;

  // ========================================
  // VALIDATE TYPE
  // ========================================

  if (!PRODUCT_TYPES.includes(type as ProductType)) {
    notFound();
  }

  const productType = type as ProductType;

  // ========================================
  // ADMIN SESSION
  // ========================================

  const adminSession = await getAdminSession();

  const isAdmin = !!adminSession;

  // ========================================
  // FIND PRODUCT
  // ========================================

  let product;

  switch (productType) {
    // ======================================
    // TOUR
    // ======================================

    case "tour":
      product = await prisma.tour.findUnique({
        where: {
          slug,
        },
      });
      break;

    // ======================================
    // TRAIN TICKET
    // ======================================

    case "train":
      product =
        await prisma.trainTicket.findUnique({
          where: {
            slug,
          },
        });
      break;

    // ======================================
    // FLIGHT TICKET
    // ======================================

    case "flight":
      product =
        await prisma.flightTicket.findUnique({
          where: {
            slug,
          },
        });
      break;

    // ======================================
    // BUS TICKET
    // ======================================

    case "bus":
      product =
        await prisma.busTicket.findUnique({
          where: {
            slug,
          },
        });
      break;

    // ======================================
    // ACCOMMODATION
    // ======================================

    case "accommodation":
      product =
        await prisma.accommodation.findUnique({
          where: {
            slug,
          },
        });
      break;

    // ======================================
    // TOURIST VISA
    // ======================================

    case "visa":
      product =
        await prisma.touristVisa.findUnique({
          where: {
            slug,
          },
        });
      break;

    default:
      notFound();
  }

  // ========================================
  // NOT FOUND
  // ========================================

  if (!product) {
    notFound();
  }

  // ========================================
  // HIDDEN PRODUCT
  // فقط Admin می‌تواند ببیند
  // ========================================

  if (!product.isPublished && !isAdmin) {
    notFound();
  }

  // ========================================
  // NORMALIZE DATA FOR CLIENT
  // ========================================

  const rawProduct = product as unknown as Record<string, unknown>;
  const adminDetails = { ...rawProduct };
  const publicDetails = { ...rawProduct };

  // These fields are used only by administrators. The public page receives
  // only the image itself (needed to render it), never image-address controls,
  // publication state, or the special-product flag.
  for (const key of ["id", "isPublished", "isSpecial", "thumbImage", "gallery", "image", "slug", "createdAt", "updatedAt"]) {
    delete publicDetails[key];
  }
  for (const [key, value] of Object.entries(publicDetails)) {
    if (value === null || value === undefined || (typeof value === "string" && value.trim() === "") || (Array.isArray(value) && value.length === 0)) {
      delete publicDetails[key];
    }
  }

  const normalizedProduct = {
    ...product,
    name: product.name ?? "",
    price: product.price === null ? null : Number(product.price),
    discountedPrice: product.discountedPrice === null ? null : Number(product.discountedPrice),
    discountPercentage: product.discountPercentage ?? null,
    capacity: "capacity" in product && product.capacity !== null ? Number(product.capacity) : null,
    remainingCapacity: "remainingCapacity" in product && product.remainingCapacity !== null ? Number(product.remainingCapacity) : null,
    isSpecial: isAdmin ? product.isSpecial : undefined,
    isPublished: isAdmin ? product.isPublished : undefined,
    details: isAdmin ? adminDetails : publicDetails,
  };

  if (!isAdmin) {
    // Remove administrative metadata from the props sent to the visitor.
    delete (normalizedProduct as unknown as Record<string, unknown>).isSpecial;
    delete (normalizedProduct as unknown as Record<string, unknown>).isPublished;
    delete (normalizedProduct as unknown as Record<string, unknown>).thumbImage;
    delete (normalizedProduct as unknown as Record<string, unknown>).gallery;
    delete (normalizedProduct as unknown as Record<string, unknown>).slug;
    delete (normalizedProduct as unknown as Record<string, unknown>).createdAt;
    delete (normalizedProduct as unknown as Record<string, unknown>).updatedAt;
  }

  // ========================================
  // RENDER
  // ========================================

  return (
    <ProductPageContent
      type={productType}
      product={normalizedProduct as ProductPageProduct}
      isAdmin={isAdmin}
    />
  );
}
