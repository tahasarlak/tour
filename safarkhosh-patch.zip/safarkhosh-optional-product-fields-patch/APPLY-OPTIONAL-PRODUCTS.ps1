﻿param(
    [Parameter(Mandatory = $false)]
    [string]$ProjectRoot = (Get-Location).Path
)

$ErrorActionPreference = "Stop"

$ProjectRoot = (Resolve-Path -LiteralPath $ProjectRoot).Path
$PatchRoot = Join-Path $PSScriptRoot "patch"

if (-not (Test-Path -LiteralPath (Join-Path $ProjectRoot "package.json"))) {
    throw "package.json پیدا نشد. مسیر ProjectRoot را روی ریشه پروژه SafarKhosh قرار بده."
}
if (-not (Test-Path -LiteralPath (Join-Path $ProjectRoot "prisma\schema.prisma"))) {
    throw "prisma/schema.prisma پیدا نشد. این Patch برای پروژه SafarKhosh است."
}

$Files = @(
    "prisma/schema.prisma",
    "prisma/migrations/20261104143000_optional_product_fields/migration.sql",
    "app/api/product/create/route.ts",
    "app/api/product/update/route.ts",
    "components/Button/CreateButton.tsx",
    "components/admin/EditableField.tsx",
    "components/admin/EditablePriceSection.tsx",
    "components/admin/EditableSingleBoolean.tsx",
    "components/admin/EditableSingleImage.tsx",
    "components/product/ProductBasicInfo.tsx",
    "components/product/ProductPageContent.tsx",
    "components/product/ProductRegistration.tsx",
    "components/ProductCard.tsx",
    "app/products/[type]/[slug]/page.tsx",
    "app/products/[type]/page.tsx",
    "app/page.tsx"
)

$BackupRoot = Join-Path $ProjectRoot ("backup-safarkhosh-optional-products-" + (Get-Date -Format "yyyyMMdd-HHmmss"))
New-Item -ItemType Directory -Path $BackupRoot -Force | Out-Null

foreach ($RelativePath in $Files) {
    $Source = Join-Path $PatchRoot $RelativePath
    $Destination = Join-Path $ProjectRoot $RelativePath
    $Backup = Join-Path $BackupRoot $RelativePath

    if (-not (Test-Path -LiteralPath $Source)) {
        throw "فایل Patch پیدا نشد: $RelativePath"
    }

    $DestinationDirectory = Split-Path -Parent $Destination
    New-Item -ItemType Directory -Path $DestinationDirectory -Force | Out-Null

    if (Test-Path -LiteralPath $Destination) {
        $BackupDirectory = Split-Path -Parent $Backup
        New-Item -ItemType Directory -Path $BackupDirectory -Force | Out-Null
        Copy-Item -LiteralPath $Destination -Destination $Backup -Force
    }

    Copy-Item -LiteralPath $Source -Destination $Destination -Force
    Write-Host "Updated: $RelativePath" -ForegroundColor Green
}

Write-Host "`nPatch copied successfully." -ForegroundColor Green
Write-Host "Backup: $BackupRoot" -ForegroundColor Cyan
Write-Host "No database command was run by this script." -ForegroundColor Yellow
