# پچ اختیاری‌سازی تمام فیلدهای محصولات SafarKhosh

این پچ بر اساس آرشیو کد پروژه‌ای که در گفتگو موجود بود ساخته شده است.

## نتیجه

- فرم ساخت محصول فقط نام، قیمت و یک عکس اصلی دارد؛ هر سه کاملاً اختیاری هستند.
- محصول حتی با خالی بودن هر سه مورد ساخته می‌شود؛ شناسه و `slug` به‌صورت سیستمی ساخته می‌شوند.
- تمام اطلاعات تکمیلی در صفحه جزئیات محصول ویرایش می‌شوند.
- فیلدهای اطلاعاتی خالی برای بازدیدکننده نمایش داده نمی‌شوند؛ ادمین فیلدهای خالی را برای تکمیل می‌بیند.
- وضعیت انتشار، محصول ویژه و آدرس تصویر اصلی/بندانگشتی/گالری فقط در بخش مخصوص ادمین نمایش داده می‌شوند.
- تصویر اصلی برای نمایش به بازدیدکننده لازم است، بنابراین مرورگر باید آدرس فایل تصویر را برای بارگذاری دریافت کند؛ اما آدرس به شکل فیلد متنی یا ابزار مدیریت به بازدیدکننده نشان داده نمی‌شود.
- فیلدهای داده‌ای در Prisma و دیتابیس nullable شده‌اند؛ مقدارهای قبلی حذف یا بازنویسی نمی‌شوند.
- اگر فیلد عددی، تاریخ، متن، آرایه یا Boolean خالی شود، API آن را به `null` یا مقدار خالی مناسب تبدیل می‌کند.

## فایل‌های تغییرکرده

- `prisma/schema.prisma`
- `prisma/migrations/20261104143000_optional_product_fields/migration.sql`
- `app/api/product/create/route.ts`
- `app/api/product/update/route.ts`
- `components/Button/CreateButton.tsx`
- `components/admin/EditableField.tsx`
- `components/admin/EditablePriceSection.tsx`
- `components/admin/EditableSingleBoolean.tsx`
- `components/admin/EditableSingleImage.tsx`
- `components/product/ProductBasicInfo.tsx`
- `components/product/ProductPageContent.tsx`
- `components/product/ProductRegistration.tsx`
- `components/ProductCard.tsx`
- `app/products/[type]/[slug]/page.tsx`
- `app/products/[type]/page.tsx`
- `app/page.tsx`

## اعمال پچ در پروژه محلی ویندوز

1. ZIP را Extract کن.
2. PowerShell را باز کن.
3. دستور زیر را با مسیر واقعی پروژه اجرا کن:

```powershell
Set-ExecutionPolicy -Scope Process Bypass -Force
.\APPLY-OPTIONAL-PRODUCTS.ps1 -ProjectRoot "D:\path\to\safarkhosh"
```

اسکریپت قبل از جایگزینی فایل‌های موجود، نسخه پشتیبان می‌سازد.

## بررسی و اعمال دیتابیس

از ریشه پروژه اجرا کن:

```bash
npx prisma validate
npx prisma migrate deploy
npx prisma generate
npm run build
```

اگر از pnpm استفاده می‌کنی، دستورات معادل:

```bash
pnpm exec prisma validate
pnpm exec prisma migrate deploy
pnpm exec prisma generate
pnpm build
```

قبل از Migration از دیتابیس نسخه پشتیبان بگیر. Migration فقط محدودیت `NOT NULL` بعضی ستون‌های اطلاعات محصول را برمی‌دارد و داده‌های فعلی را پاک نمی‌کند.

## نکته مهم

فیلد `type` برای تعیین مدل محصول همچنان لازم است و فیلدهای سیستمی مثل `id`، `slug` و زمان‌های ایجاد/ویرایش خودکار ساخته می‌شوند. این‌ها فیلدهای محتوایی فرم نیستند.

در محیط آماده‌سازی این بسته، وابستگی‌های پروژه (`node_modules`) نصب نبودند؛ بنابراین اجرای کامل `prisma validate` و `next build` ممکن نبود و موفقیت Build تضمین‌شده اعلام نمی‌شود. بعد از کپی روی پروژه اصلی، ابتدا وابستگی‌ها را نصب کن و سپس دستورات بررسی پایین را اجرا کن.

نکته: فیلدهای آرایه‌ای در دیتابیس با آرایه خالی `[]` و فیلد JSON برنامه سفر با مقدار پیش‌فرض `[]` خالی می‌مانند؛ این رفتار برای جلوگیری از خطای نوع داده است. آدرس تصویر اصلی برای بارگذاری خود تصویر ناچاراً به مرورگر فرستاده می‌شود، اما فیلد متنی/ابزار ویرایش آدرس تصویر، آدرس بندانگشتی، گالری و تنظیمات مدیریتی فقط در رابط ادمین نمایش داده می‌شوند.
